<html>
    <head>
        <title>Problema</title>
    </head>
    <body>
        <?php
        echo "La fecha de hoy es"; 
        $fecha = date("j/n/y");  
        echo $fecha; 
        echo "<br>";  
        ?>
        <a href="fecha3.php">Siguiente problema</a>
    </body>
</html>
