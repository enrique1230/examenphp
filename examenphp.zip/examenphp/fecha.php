<html>
    <head>
        <title>Problema</title>
    </head>
    <body>
        <?php
        echo "La fecha de hoy es"; 
        $fecha=date ("d/m/Y"); 
          echo $fecha; 
        echo "<br>"; 
        echo "La hora actual es"; 
        $hora = date("H:i:s"); 
        echo $hora; 
        echo "<br>"; 
        ?>
        <a href="fecha2.php">Siguiente problema</a>
    </body>
</html>

